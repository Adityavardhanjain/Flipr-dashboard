// Import necessary modules and models
const express = require('express');
const router = express.Router();
const orderController = require('../controllers/ordercontroller'); // Import order controller

// GET all orders
router.get('/', orderController.getAllOrders);

// GET a single order by ID
router.get('/:id', orderController.getOrderById);

// POST create a new order
router.post('/', orderController.createOrder);

// PUT update an order by ID
router.put('/:id', orderController.updateOrderById);

// DELETE an order by ID
router.delete('/:id', orderController.deleteOrderById);

module.exports = router;
