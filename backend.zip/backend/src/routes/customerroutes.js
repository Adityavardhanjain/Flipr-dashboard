// Import necessary modules and models
const express = require('express');
const router = express.Router();
const customerController = require('../controllers/customercontroller'); // Import customer controller

// GET all customers
router.get('/', customerController.getAllCustomers);

// GET a single customer by ID
router.get('/:id', customerController.getCustomerById);

// POST create a new customer
router.post('/', customerController.createCustomer);

// PUT update a customer by ID
router.put('/:id', customerController.updateCustomerById);

// DELETE a customer by ID
router.delete('/:id', customerController.deleteCustomerById);

module.exports = router;
