// Import necessary modules and models
const express = require('express');
const router = express.Router();
const shippingController = require('../controllers/shippingcontroller'); // Import shipping controller

// GET all shipping details
router.get('/', shippingController.getAllShippingDetails);

// GET a single shipping detail by ID
router.get('/:id', shippingController.getShippingDetailById);

// POST create a new shipping detail
router.post('/', shippingController.createShippingDetail);

// PUT update a shipping detail by ID
router.put('/:id', shippingController.updateShippingDetailById);

// DELETE a shipping detail by ID
router.delete('/:id', shippingController.deleteShippingDetailById);

module.exports = router;
