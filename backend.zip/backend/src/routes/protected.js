// routes/protected.js

const express = require('express');
const verifyToken = require('../Middleware/auth');

const router = express.Router();

// Protected Route
router.get('/protected', verifyToken, (req, res) => {
  res.status(200).json({ message: 'Protected route accessed successfully', user: req.user });
});

module.exports = router;
