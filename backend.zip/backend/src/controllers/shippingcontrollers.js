const ShippingDetail = require('../models/shippingmodel');

// Controller function to get all shipping details
exports.getAllShippingDetails = async (req, res) => {
  try {
    const shippingDetails = await ShippingDetail.find();
    res.json(shippingDetails);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Controller function to get a single shipping detail by ID
exports.getShippingDetailById = async (req, res) => {
  try {
    const shippingDetail = await ShippingDetail.findById(req.params.id);
    if (!shippingDetail) {
      return res.status(404).json({ message: 'Shipping detail not found' });
    }
    res.json(shippingDetail);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// Controller function to create a new shipping detail
exports.createShippingDetail = async (req, res) => {
  const shippingDetail = new ShippingDetail({
    address: req.body.address,
    city: req.body.city,
    pincode: req.body.pincode,
    purchaseOrderId: req.body.purchaseOrderId,
    customerId: req.body.customerId
  });
  try {
    const newShippingDetail = await shippingDetail.save();
    res.status(201).json(newShippingDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Controller function to update a shipping detail by ID
exports.updateShippingDetailById = async (req, res) => {
  try {
    const shippingDetail = await ShippingDetail.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!shippingDetail) {
      return res.status(404).json({ message: 'Shipping detail not found' });
    }
    res.json(shippingDetail);
  } catch (err) {
    res.status(400).json({ message: err.message });
  }
};

// Controller function to delete a shipping detail by ID
exports.deleteShippingDetailById = async (req, res) => {
  try {
    const shippingDetail = await ShippingDetail.findByIdAndDelete(req.params.id);
    if (!shippingDetail) {
      return res.status(404).json({ message: 'Shipping detail not found' });
    }
    res.json({ message: 'Shipping detail deleted' });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
