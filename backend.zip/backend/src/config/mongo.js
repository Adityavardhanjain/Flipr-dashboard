const { MongoClient } = require('mongodb');

// MongoDB connection URL
const uri = 'mongodb+srv://jainadityavardhan:<password>@cluster0.ghogzpy.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0';
async function connectToDatabase() {
    try {
        const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
        await client.connect();
        console.log('Connected to MongoDB Atlas');
        return client.db();
    } catch (error) {
        console.error('Error connecting to MongoDB Atlas:', error);
        throw error;
    }
}
