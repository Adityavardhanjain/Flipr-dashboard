<template>
    <div>
      <h2>Add Customer</h2>
      <form @submit.prevent="addCustomer">
        <label for="name">Name:</label>
        <input type="text" id="name" v-model="customer.name" required>
        
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="customer.email" required>
        
        <label for="mobileNumber">Mobile Number:</label>
        <input type="text" id="mobileNumber" v-model="customer.mobileNumber" required>
        
        <label for="city">City:</label>
        <input type="text" id="city" v-model="customer.city" required>
        
        <button type="submit">Add Customer</button>
      </form>
    </div>
  </template>
  
  <script>
  import axios from 'axios';
  
  export default {
    data() {
      return {
        customer: {
          name: '',
          email: '',
          mobileNumber: '',
          city: ''
        }
      };
    },
    methods: {
      addCustomer() {
        axios.post('http://localhost:5000/api/customers', this.customer)
          .then(response => {
            console.log(response.data);
            // Optionally, perform actions after successful addition
          })
          .catch(error => {
            console.error(error);
            // Optionally, handle error
          });
      }
    }
  };
  </script>
  