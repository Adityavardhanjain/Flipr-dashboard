<template>
    <div>
      <h2>Customer Management</h2>
      <!-- Customer Form -->
      <b-form @submit.prevent="addCustomer">
        <b-form-group label="Name">
          <b-form-input v-model="customer.name" placeholder="Enter name"></b-form-input>
        </b-form-group>
        <b-form-group label="Email">
          <b-form-input v-model="customer.email" type="email" placeholder="Enter email"></b-form-input>
        </b-form-group>
        <b-form-group label="Mobile Number">
          <b-form-input v-model="customer.mobileNumber" placeholder="Enter mobile number"></b-form-input>
        </b-form-group>
        <b-form-group label="City">
          <b-form-input v-model="customer.city" placeholder="Enter city"></b-form-input>
        </b-form-group>
        <b-button type="submit" variant="primary">Add Customer</b-button>
      </b-form>
      <!-- Display list of customers -->
      <ul>
        <li v-for="customer in customers" :key="customer.id">{{ customer.name }}</li>
      </ul>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        customer: {
          name: '',
          email: '',
          mobileNumber: '',
          city: ''
        },
        customers: [] // Array to store customer data
      };
    },
    methods: {
      addCustomer() {
        // Logic to add customer
        this.customers.push({ ...this.customer, id: this.customers.length + 1 });
        this.customer = {
          name: '',
          email: '',
          mobileNumber: '',
          city: ''
        };
      }
    }
  };
  </script>
  